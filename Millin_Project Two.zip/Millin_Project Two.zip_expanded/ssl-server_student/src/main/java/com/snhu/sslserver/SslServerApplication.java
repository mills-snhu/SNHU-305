package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

//Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController{ 
	
		    public static String Hash(String input) {
		        try {
		            // Create a MessageDigest instance for SHA-256
		            MessageDigest digest = MessageDigest.getInstance("SHA-256");

		            // Perform the hash computation
		            byte[] encodedhash = digest.digest(input.getBytes(StandardCharsets.UTF_8));

		            // Convert byte array into a hexadecimal string
		            StringBuilder hexString = new StringBuilder();
		            for (byte b : encodedhash) {
		                String hex = Integer.toHexString(0xff & b);
		                if (hex.length() == 1) {
		                    hexString.append('0');
		                }
		                hexString.append(hex);
		            }
		            return hexString.toString();
		        } catch (NoSuchAlgorithmException e) {
		            throw new RuntimeException(e);
		        }
		    }
		
		
	    @RequestMapping("/hash")
	 
	    public String myHash() throws NoSuchAlgorithmException{
	    	String data = "Howdy Shawn Millin Congrats on your Checksum";
	    	String hash = Hash(data);
	      
	        return "<p>This is the data: "+ data + "</p><p>The ciper used is SHA-256" + "</p><p>Checksum value:" + hash ;
	    }
	
}

